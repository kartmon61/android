package org.techtown.cinema;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ShowAllCommentActivity extends AppCompatActivity {
    //선언부분
    Button btnWriteComment;
    Intent intent;
    CommentItem commentItem;
    ArrayList<CommentItem> commentItems;
    CommentAdapter commentAdapter;
    ListView listViewAllComments;


    //==========================onCreate 부분==========================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_comment);

        btnWriteComment = (Button) findViewById(R.id.button_writeComment);

        //작성하기 버튼을 눌렀을 때
        btnWriteComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCommentWriteActivity();
            }
        });

        intent = getIntent();
        processIntent(intent);

        listViewAllComments = (ListView) findViewById(R.id.listView_allComments);
        listViewAllComments.setAdapter(commentAdapter);
        commentAdapter.notifyDataSetChanged();

    }
    //==========================onCreate 종료==========================

    //intent에 있는 데이터를 가져오는 메소드
    public void processIntent(Intent intent){
        if(intent != null){
            commentItems =  getIntent().getParcelableArrayListExtra("listData");

            commentAdapter = new CommentAdapter();
            for(int i=0;i<commentItems.size();i++){
                commentAdapter.addItem(commentItems.get(i));
                commentAdapter.notifyDataSetChanged();
            }
        }
    }

    //==========================작성하는 버튼을 눌렀을 때 동작하는 메소드==========================
    public void showCommentWriteActivity(){
        commentItem = new CommentItem("kartmon","",0f,R.drawable.user1,0);
        intent = new Intent(getApplicationContext(),CommentWriteActivity.class);

        intent.putExtra("itemData",commentItem);
        startActivityForResult(intent,102);
    }

    //==========================뒤로가기 버튼을 눌렀을 때 동작==========================
    @Override
    public void onBackPressed() {
        intent = new Intent();
        intent.putExtra("returnList",commentItems);
        setResult(RESULT_OK,intent);
        finish();
        super.onBackPressed();


    }


    //==========================onActivityResult==========================
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        //작성하기에서 돌아왔을때 동작
        if(requestCode == 102){
            if(intent != null){
                commentItem = intent.getParcelableExtra("returnData");
                commentItems.add(commentItem);
                commentAdapter.addItem(commentItem);
                commentAdapter.notifyDataSetChanged();
            }
        }
    }


}
