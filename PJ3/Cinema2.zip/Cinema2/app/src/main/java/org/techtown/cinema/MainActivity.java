package org.techtown.cinema;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //버튼 객체 생성
    Button btnGood;
    Button btnBad;
    Button btnWriteComment;
    Button btnCommentShowAll;
    Button btnReserve;
    Button btnKakao;
    Button btnFaceBook;

    //텍스트뷰 객체 생성
    TextView tvShowGood;
    TextView tvShowBad;

    //좋아요 상태, 갯수
    int goodBadState = 0;
    int likeGoodCount;
    int likeBadCount;

    //어뎁터 객체 생성
    Intent intent;
    CommentAdapterLimit commentAdapter;

    //댓글을 보관하는 객체 생성
    ArrayList<CommentItem> commentItems;


    //==========================onCreate 부분==========================
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //버튼 선언
        btnGood = (Button) findViewById(R.id.button_good);
        btnBad = (Button) findViewById(R.id.button_bad);
        btnWriteComment = (Button) findViewById(R.id.button_writeComment);
        btnCommentShowAll = (Button) findViewById(R.id.button_comment_show_all);
        btnKakao = (Button) findViewById(R.id.button_kakao);
        btnFaceBook = (Button) findViewById(R.id.button_faceBook);
        btnReserve = (Button) findViewById(R.id.button_reserve);

        //텍스트뷰 선언
        tvShowGood = (TextView) findViewById(R.id.textView_showGood);
        tvShowBad = (TextView) findViewById(R.id.textView_showBad);



        //리스트 뷰 생성
        ListView listView_comments = (ListView) findViewById(R.id.listView_comments);
        //코멘트 어뎁터 객체 선언
        commentAdapter = new CommentAdapterLimit();
        //데이터 저장할 arrayList 선언
        commentItems = new ArrayList<>();
        //예시 댓글 생성
        addItem();
        //리스트뷰에 어뎁터 적용
        listView_comments.setAdapter(commentAdapter);
        //각 버튼을 눌렀을 때 동작하는 메소드
        buttonClicked();
    }
    //==========================onCreate 종료==========================


    //================버튼이 눌렸을 때 동작 함수=======================
    public void buttonClicked(){
        //좋아요 버튼을 눌렀을때
        btnGood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //아무것도 눌러져있지 않을때 상태 0
                if(goodBadState==0){
                    goodBadState = 1;
                    incLikeCount(goodBadState);

                }
                //좋아요 버튼이 눌러져있을때 상태 1
                else if(goodBadState==1){
                    decLikeCount(goodBadState);
                    goodBadState = 0;
                }
                //싫어요 버튼이 이미 눌러져 있을때 상태 2
                else{
                    decLikeCount(goodBadState);
                    goodBadState = 1;
                    incLikeCount(goodBadState);
                }
            }
        });

        //싫어요 버튼을 눌렀을때
        btnBad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //아무것도 눌러져있지 않을때 상태 0
                if(goodBadState==0){
                    goodBadState = 2;
                    incLikeCount(goodBadState);
                }
                //싫어요 버튼이 이미 눌러져 있을때 상태 2
                else if(goodBadState==2){
                    decLikeCount(goodBadState);
                    goodBadState = 0;
                }
                //좋아요 버튼이 눌러져있을때 상태 1
                else{
                    decLikeCount(goodBadState);
                    goodBadState = 2;
                    incLikeCount(goodBadState);
                }

            }
        });

        //작성하기 버튼을 눌렀을때
        btnWriteComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "작성하기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
                showCommentWriteActivity();
            }
        });


        //모두보기 버튼 눌렀을때
        btnCommentShowAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "모두보기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
                showAllCommentActivity();
            }
        });

        //카카오톡 버튼 눌렀을때
        btnKakao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "카카오톡 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        //페이스북 버튼 눌렀을때
        btnFaceBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "페이스북 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        //예매하기 버튼 눌렀을때
        btnReserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "예매하기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //==========================예시 댓글 생성 함수=======================
    public void addItem(){
        //댓글 추가1
        commentAdapter.addItem(
                new CommentItem
                        ("ltwljh","적당히 재밌다. 오랜만에 잠안오는 영화를 봤네요",3.1f,R.drawable.user1,0));
        commentItems.add(new CommentItem
                ("ltwljh","적당히 재밌다. 오랜만에 잠안오는 영화를 봤네요",3.1f,R.drawable.user1,0));
        //댓글 추가2
        commentAdapter.addItem(
                new CommentItem
                        ("kartmon","영화가 너무 재미있었어요",4.2f,R.drawable.user1,2));
        commentItems.add( new CommentItem
                ("kartmon","영화가 너무 재미있었어요",4.2f,R.drawable.user1,2));
        //댓글 추가3
        commentAdapter.addItem(
                new CommentItem
                        ("kartmon2","영화가 너무 재미있었어요",4.2f,R.drawable.user1,1));
        commentItems.add( new CommentItem
                ("kartmon2","영화가 너무 재미있었어요",4.2f,R.drawable.user1,1));

    }

    //==============모두 보기 버튼을 눌렀을 때 동작하는 메소드=============
    public void showAllCommentActivity(){
        intent = new Intent(getApplicationContext(),ShowAllCommentActivity.class);
        intent.putParcelableArrayListExtra("listData",commentItems);
        startActivityForResult(intent,101);
    }

    //================작성하기 버튼을 눌렀을 때 동작하는 메소드==========
    public void showCommentWriteActivity(){
        CommentItem commentItem = new CommentItem("kartmon","",0f,R.drawable.user1,0);
        intent = new Intent(getApplicationContext(),CommentWriteActivity.class);

        intent.putExtra("itemData",commentItem);
        startActivityForResult(intent,102);
    }


    //==========================onActivityResult==========================
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        //모두보기에서 돌아왔을 때 동작
        if(requestCode == 101){

            if(intent!=null){
                commentItems = intent.getParcelableArrayListExtra("returnList");
            }
        }

        //작성하기에서 돌아왔을 때 동작
        if(requestCode == 102){
            if(intent != null){
                CommentItem commentItem = intent.getParcelableExtra("returnData");
                commentItems.add(commentItem);
                commentAdapter.addItem(commentItem);
                commentAdapter.notifyDataSetChanged();
            }
        }
    }

    //==========================버튼을 눌렀을때 숫자 증가 메소드==========================
    public void incLikeCount(int good_bad_state){
        //각각 좋아요갯수와 싫어요 갯수 가져오기
        likeGoodCount = Integer.parseInt(tvShowGood.getText().toString());
        likeBadCount = Integer.parseInt(tvShowBad.getText().toString());
        //좋아요 버튼을 눌렀을때
        if(good_bad_state == 1){
            likeGoodCount++;
            tvShowGood.setText(String.valueOf(likeGoodCount));
            btnGood.setBackgroundResource(R.drawable.ic_thumb_up_selected);
        }
        //싫어요 버튼을 눌렀을때
        else{
            likeBadCount++;
            tvShowBad.setText(String.valueOf(likeBadCount));
            btnBad.setBackgroundResource(R.drawable.ic_thumb_down_selected);
        }
    }

    //==========================버튼을 눌렀을때 숫자 감소 메소드==========================
    public void decLikeCount(int good_bad_state){
        //각각 좋아요갯수와 싫어요 갯수 가져오기
        likeGoodCount = Integer.parseInt(tvShowGood.getText().toString());
        likeBadCount = Integer.parseInt(tvShowBad.getText().toString());
        //좋아요 버튼을 눌렀을때
        if(good_bad_state == 1){
            likeGoodCount--;
            tvShowGood.setText(String.valueOf(likeGoodCount));
            btnGood.setBackgroundResource(R.drawable.button_good_change);
        }
        //싫어요 버튼을 눌렀을때
        else{
            likeBadCount--;
            tvShowBad.setText(String.valueOf(likeBadCount));
            btnBad.setBackgroundResource(R.drawable.button_bad_change);
        }
    }
}
