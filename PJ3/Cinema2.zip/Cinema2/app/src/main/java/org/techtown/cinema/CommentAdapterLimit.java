package org.techtown.cinema;

//commentAdapter의 item을 2개로 제한
class CommentAdapterLimit extends CommentAdapter{
    @Override
    public int getCount() {

        return 2;
    }

}