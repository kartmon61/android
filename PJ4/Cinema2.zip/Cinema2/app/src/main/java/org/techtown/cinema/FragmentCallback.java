package org.techtown.cinema;


import android.os.Bundle;

public interface FragmentCallback {
    //프래그먼트 이동
    public void onFragmentChange();
    //영화 번들 생성
    public void setMovieDetail(Bundle bundle);
    //영화 번들 가져오기
    public Bundle getMovieDetail();
    //모두보기 액티비티로 이동
    public void showAllCommentActivity();
    //글쓰기 액티비티로 이동
    public void showCommentWriteActivity();

}
