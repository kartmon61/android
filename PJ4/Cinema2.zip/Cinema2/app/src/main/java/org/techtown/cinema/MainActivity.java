package org.techtown.cinema;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import com.google.android.material.navigation.NavigationView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener ,FragmentCallback{

    FragmentMoviePager fragmentMoviePager;
    FragmentMovieList fragmentMovieList;
    FragmentMovieList fragmentMovieList2;
    FragmentMovieList fragmentMovieList3;
    FragmentMovieList fragmentMovieList4;
    FragmentMovieList fragmentMovieList5;
    FragmentMovieList fragmentMovieList6;
    FragmentMovieDetail fragmentMovieDetail;
    MoviePagerAdapter pagerAdapter;
    Intent intent;

    Bundle movieDetail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_short_cut);

        fragmentMovieDetail = new FragmentMovieDetail();
        movieDetail = new Bundle();

        //프래그먼트에 영화 리스트 추가
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        //페이저 어댑터 생성
        createPager();

        //페이저 프래그먼트 호출
        getSupportFragmentManager().beginTransaction()
                .add(R.id.container,fragmentMoviePager).commit();
    }

    //==============프래그먼트 페이저 생성 메소드==============
    public void createPager(){
        fragmentMoviePager = new FragmentMoviePager();
        pagerAdapter = new MoviePagerAdapter(getSupportFragmentManager());

        setMovieList(1,fragmentMovieList);
        setMovieList(2,fragmentMovieList2);
        setMovieList(3,fragmentMovieList3);
        setMovieList(4,fragmentMovieList4);
        setMovieList(5,fragmentMovieList5);
        setMovieList(6,fragmentMovieList6);

        //프래그먼트 페이저에 어뎁터 전달
        fragmentMoviePager.setPager(pagerAdapter);
    }


    //==============네비게이션 뒤로가기 처리 메소드==============
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //==============네비게이션 버튼 선택 이동 메소드==============
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_list) {
            Toast.makeText(this,"영화 리스트 메뉴 선택됨.",Toast.LENGTH_LONG).show();
            createPager();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container,fragmentMoviePager).commit();

        } else if (id == R.id.nav_api) {
            Toast.makeText(this,"영화 api 메뉴 선택됨.",Toast.LENGTH_LONG).show();
        } else if (id == R.id.nav_book) {
            Toast.makeText(this,"영화 예약 메뉴 선택됨.",Toast.LENGTH_LONG).show();
        } else if (id == R.id.nav_option) {
            Toast.makeText(this,"영화 옵션 메뉴 선택됨.",Toast.LENGTH_LONG).show();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    //==============영화 목록 추가 메소드==============
    public void setMovieList(int num,FragmentMovieList fragmentMovieList){
        fragmentMovieList = new FragmentMovieList();

        if(num == 1){
            Bundle movie1 = newMovieList(1,"군 도",61.6,15,R.drawable.image1,
                    R.drawable.image11);
            fragmentMovieList.setArguments(movie1);

        }
        else if(num == 2){
            Bundle movie2 = newMovieList(2,"공 조",61.6,15,R.drawable.image2,
                    R.drawable.image22);
            fragmentMovieList.setArguments(movie2);

        }
        else if(num == 3){
            Bundle movie3 = newMovieList(3,"더 킹",61.6,15,R.drawable.image3,
                    R.drawable.image33);
            fragmentMovieList.setArguments(movie3);

        }
        else if(num ==4){
            Bundle movie4 = newMovieList(4,"레지던트이블",61.6,15,R.drawable.image4,
                    R.drawable.image44);
            fragmentMovieList.setArguments(movie4);

        }
        else if(num ==5){
            Bundle movie5 = newMovieList(5,"럭 키",61.6,15,R.drawable.image5,
                    R.drawable.image55);
            fragmentMovieList.setArguments(movie5);

        }
        else if(num == 6){
            Bundle movie6 = newMovieList(6,"아수라",61.6,15,R.drawable.image6,
                    R.drawable.image66);
            fragmentMovieList.setArguments(movie6);

        }

        pagerAdapter.addItem(fragmentMovieList);
    }

    //영화 정보를 번들로 저장하는 메소드
    public Bundle newMovieList(int movieNum ,String movieTitle,Double movieRate,int movieAge,int resId,int resId2){
        Bundle movie = new Bundle();
        movie.putInt("num",movieNum);
        movie.putString("title",movieTitle);
        movie.putDouble("rate",movieRate);
        movie.putInt("age",movieAge);
        movie.putInt("resId",resId);
        movie.putInt("resId2",resId2);

        return movie;
    }

    public void setMovieDetail(Bundle bundle){
        movieDetail = new Bundle();
        movieDetail = bundle;
    }

    public Bundle getMovieDetail(){
        return movieDetail;
    }

    //==============상세화면 페이지로 전환하는 메소드==============
    public void onFragmentChange(){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container,fragmentMovieDetail).commit();
    }

        //==============모두 보기 버튼을 눌렀을 때 동작하는 메소드=============
    public void showAllCommentActivity(){
        intent = new Intent(getApplicationContext(),ShowAllCommentActivity.class);
        intent.putParcelableArrayListExtra("listData", fragmentMovieDetail.commentAdapter.getCommentItems());
        //intent.putParcelableArrayListExtra("listData",fragmentMovieDetail.commentItems);
        startActivityForResult(intent,101);
    }

    //================작성하기 버튼을 눌렀을 때 동작하는 메소드==========
    public void showCommentWriteActivity(){
        CommentItem commentItem = new CommentItem("kartmon","",0f,R.drawable.user1,0);
        intent = new Intent(getApplicationContext(),CommentWriteActivity.class);
        intent.putExtra("itemData",commentItem);
        startActivityForResult(intent,102);
    }

    //==========================onActivityResult==========================
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        //모두보기에서 돌아왔을 때 동작
        if(requestCode == 101 && intent!=null){
            ArrayList<CommentItem> commentItems;
            commentItems = intent.getParcelableArrayListExtra("returnList");
            fragmentMovieDetail.commentAdapter = new CommentAdapter(true);
            for(int i=0;i<commentItems.size();i++){
                fragmentMovieDetail.commentAdapter.addItem(commentItems.get(i));
            }
            fragmentMovieDetail.commentAdapter.notifyDataSetChanged();
        }

        //작성하기에서 돌아왔을 때 동작
        if(requestCode == 102 && intent !=null){
                CommentItem commentItem = intent.getParcelableExtra("returnData");
                //fragmentMovieDetail.commentItems.add(commentItem);
                fragmentMovieDetail.commentAdapter.addItem(commentItem);
                fragmentMovieDetail.commentAdapter.notifyDataSetChanged();
        }
    }
}
