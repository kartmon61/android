package org.techtown.cinema;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

public class FragmentMoviePager extends Fragment {

    MoviePagerAdapter pagerAdapter;
    ViewPager pager;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    //==========================onCreate 부분==========================
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_view_pager,container,false);
        getActivity().setTitle("영화 목록");

        pager = (ViewPager) rootView.findViewById(R.id.pager);
        pager.setOffscreenPageLimit(6);
        pager.setAdapter(pagerAdapter);

        return rootView;
    }
    //==========================onCreate 종료==========================


    //액티비티에서 페이저 어뎁터 전달 받는 메소드
    public void setPager(MoviePagerAdapter adapter){

        pagerAdapter = adapter;
    }




}
