package org.techtown.cinema;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentMovieList extends Fragment {

    private TextView movieTitleNum;
    private TextView movieTitle;
    private ImageView movieImg;
    private TextView movieRate;
    private TextView movieAge;
    private Button movieDetail;
    FragmentCallback callback;
    Bundle movie;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof FragmentCallback){
            callback = (FragmentCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        if(callback != null){
            callback=null;
        }
    }

    //==========================onCreate 부분==========================
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_movie_list,container,false);
        movieTitleNum = (TextView)rootView.findViewById(R.id.textView_movieTitleNum);
        movieTitle = (TextView)rootView.findViewById(R.id.textView_movieTitle);
        movieImg = (ImageView)rootView.findViewById(R.id.imageView_movieImg);
        movieRate = (TextView)rootView.findViewById(R.id.textView_movieRate1);
        movieAge = (TextView)rootView.findViewById(R.id.textView_movieAge);
        movieDetail = (Button)rootView.findViewById(R.id.button_movieDetail);

        getNewMovieList();

        //영화 상세화면으로 이동
        movieDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(),"상세화면으로 이동합니다..",Toast.LENGTH_LONG).show();
                if(callback!=null){
                    callback.setMovieDetail(movie);
                    callback.onFragmentChange();
                }
            }
        });

        return rootView;
    }
    //==========================onCreate 종료==========================

//    //영화 정보를 번들로 저장하는 메소드
//    public Bundle newMovieList(int movieNum ,String movieTitle,Double movieRate,int movieAge,int resId,int resId2){
//        Bundle movie = new Bundle();
//        movie.putInt("num",movieNum);
//        movie.putString("title",movieTitle);
//        movie.putDouble("rate",movieRate);
//        movie.putInt("age",movieAge);
//        movie.putInt("resId",resId);
//        movie.putInt("resId2",resId2);
//
//        return movie;
//    }

    //액티비티로부터 정보를 가져와 프래그먼트에 저장하는 메소드
    public void getNewMovieList(){
        int movieNum = getArguments().getInt("num");
        String title = getArguments().getString("title");
        String rate = Double.toString(getArguments().getDouble("rate"));
        int age = getArguments().getInt("age");
        int resId = getArguments().getInt("resId");
        int resId2 = getArguments().getInt("resId2");

        movie = new Bundle();
        movie.putString("title",title);
        movie.putInt("resId2",resId2);

        movieTitleNum.setText(movieNum+"");
        movieTitle.setText(title);
        movieRate.setText(rate);
        movieAge.setText(age+"");
        movieImg.setImageResource(resId);

    }


}
