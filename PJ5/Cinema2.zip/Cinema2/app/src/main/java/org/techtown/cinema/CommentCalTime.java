package org.techtown.cinema;

public class CommentCalTime {
    long curTime;
    long diffTime;

    private static class TimeConstants{
        public static final int SEC = 60;
        public static final int MIN = 60;
        public static final int HOUR = 24;
        public static final int DAY = 30;
        public static final int MONTH = 12;
    }


    public String formatTimeString(long regTime) {
        curTime = System.currentTimeMillis();
        diffTime = (curTime - regTime) / 1000;
        String msg = null;
        if (diffTime < TimeConstants.SEC) {
            msg = "방금 전";
        } else if ((diffTime /= TimeConstants.SEC) < TimeConstants.MIN) {
            msg = diffTime + "분 전";
        } else if ((diffTime /= TimeConstants.MIN) < TimeConstants.HOUR) {
            msg = (diffTime) + "시간 전";
        } else if ((diffTime /= TimeConstants.HOUR) < TimeConstants.DAY) {
            msg = (diffTime) + "일 전";
        } else if ((diffTime /= TimeConstants.DAY) < TimeConstants.MONTH) {
            msg = (diffTime) + "달 전";
        } else {
            msg = (diffTime) + "년 전";
        }
        return msg;
    }
}
