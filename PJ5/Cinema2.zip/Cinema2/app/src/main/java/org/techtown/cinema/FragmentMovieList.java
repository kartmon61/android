package org.techtown.cinema;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import org.techtown.cinema.data.MovieDetail;
import org.techtown.cinema.data.MovieDetailList;
import org.techtown.cinema.data.MovieList;
import org.techtown.cinema.data.ResponseInfo;


public class FragmentMovieList extends Fragment {

    private TextView movieTitleNum;
    private TextView movieTitle;
    private ImageView movieImg;
    private TextView movieRate;
    private TextView movieAge;
    private Button movieDetail;
    String title;
    String resId;
    FragmentCallback callback;
    Bundle movie;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof FragmentCallback){
            callback = (FragmentCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        if(callback != null){
            callback=null;
        }
    }

    //==========================onCreate 부분==========================
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_movie_list,container,false);
        movieTitleNum = (TextView)rootView.findViewById(R.id.textView_movieTitleNum);
        movieTitle = (TextView)rootView.findViewById(R.id.textView_movieTitle);
        movieImg = (ImageView)rootView.findViewById(R.id.imageView_movieImg);
        movieRate = (TextView)rootView.findViewById(R.id.textView_movieRate1);
        movieAge = (TextView)rootView.findViewById(R.id.textView_movieAge);
        movieDetail = (Button)rootView.findViewById(R.id.button_movieDetail);


        getNewMovieList();
        sendImageRequest(resId);

        //영화 상세화면으로 이동
        movieDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(),"상세화면으로 이동합니다..",Toast.LENGTH_LONG).show();
                if(callback!=null){
                    requestMovieList(title);

                }
            }
        });
        return rootView;
    }
    //==========================onCreate 종료==========================


    public void sendImageRequest(String url1){
        String url = url1;
        ImageLoadTask task = new ImageLoadTask(url,movieImg);
        task.execute();
    }


    //액티비티로부터 정보를 가져와 프래그먼트에 저장하는 메소드
    public void getNewMovieList(){
        movie = new Bundle();
        movie = getArguments().getBundle("movie");
        //Log.d("movie",movie.toString());

        int movieNum = movie.getInt("num");
        title = movie.getString("title");
        String rate = Float.toString(movie.getFloat("rate"));
        int age = movie.getInt("age");
        resId = movie.getString("resId");
        String resId2 = movie.getString("resId2");

        movieTitleNum.setText(movieNum+"");
        movieTitle.setText(title);
        movieRate.setText(rate);
        movieAge.setText(age+"");

    }

    //==============영화 목록 가져오는 메소드==============
    public void requestMovieList(String title){
        String url = "http://" + AppHelper.host + ":" + AppHelper.port + "/movie/readMovie";
        url += "?" + "name="+title;

        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        callback.println("응답 받음 => " + response);
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        callback.println("에러 발생 => " + error.getMessage());
                    }
                }
        );
        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
        callback.println("영화목록 요청 보냄");
    }


    public void processResponse(String response){
        Gson gson = new Gson();

        ResponseInfo info = gson.fromJson(response,ResponseInfo.class);
        if(info.code == 200){
            MovieDetailList movieList = gson.fromJson(response, MovieDetailList.class);
            MovieDetail movieDetail = movieList.result.get(0);

            movie.putInt("like",movieDetail.like);
            movie.putInt("dislike",movieDetail.dislike);
            movie.putString("synopsis",movieDetail.synopsis);
            movie.putString("genre",movieDetail.genre);
            movie.putInt("duration",movieDetail.duration);
            movie.putInt("audience",movieDetail.audience);
            movie.putFloat("audience_rating",movieDetail.audience_rating);
            movie.putFloat("reviewer_rating",movieDetail.reviewer_rating);
            movie.putString("date",movieDetail.date);
            movie.putString("director",movieDetail.director);
            movie.putString("actor",movieDetail.actor);
            Log.d("movie 출력 ",movie.toString());
            callback.setMovieDetail(movie);
            callback.onFragmentChange();
        }
    }

}
