package org.techtown.cinema.data;

public class ResponseInfo {

    public String message;
    public int code;
    public String resultType;
}
