package org.techtown.cinema;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


public class FragmentMovieDetail extends Fragment {

    FragmentCallback callback;
    Bundle movie;

    //버튼 객체 생성
    Button btnGood;
    Button btnBad;
    Button btnWriteComment;
    Button btnCommentShowAll;
    Button btnReserve;
    Button btnKakao;
    Button btnFaceBook;

    //텍스트뷰 객체 생성
    TextView tvShowGood;
    TextView tvShowBad;
    TextView tvMovieTitle;
    TextView tvSynopsis;
    TextView tvDate;
    TextView tvGenre;
    TextView tvAudience;
    TextView tvActor;
    TextView tvDirector;

    ImageView imgMovie;

    //좋아요 상태, 갯수
    int goodBadState = 0;
    int likeGoodCount;
    int likeBadCount;

    CommentAdapter commentAdapter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof FragmentCallback){
            callback = (FragmentCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        if(callback != null){
            callback=null;
        }
    }

    //==========================onCreate 부분==========================
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.activity_movie_detail, container, false);
        getActivity().setTitle("영화 상세");

        btnGood = rootView.findViewById(R.id.button_good);
        btnBad = rootView.findViewById(R.id.button_bad);
        btnWriteComment = rootView.findViewById(R.id.button_writeComment);
        btnCommentShowAll = rootView.findViewById(R.id.button_comment_show_all);
        btnReserve = rootView.findViewById(R.id.button_reserve);
        btnKakao = rootView.findViewById(R.id.button_kakao);
        btnFaceBook = rootView.findViewById(R.id.button_faceBook);
        tvShowGood = rootView.findViewById(R.id.textView_showGood);
        tvShowBad = rootView.findViewById(R.id.textView_showBad);
        imgMovie = rootView.findViewById(R.id.imageView_moviePoster);
        tvMovieTitle = rootView.findViewById(R.id.textView_movieName);
        tvSynopsis = rootView.findViewById(R.id.textView_movieStory);
        tvAudience = rootView.findViewById(R.id.textView_moviePeople);
        tvActor = rootView.findViewById(R.id.textView_actors);
        tvDirector = rootView.findViewById(R.id.textView_director);
        tvDate = rootView.findViewById(R.id.textView_movieOpen);


        setMovieDetail();


        //리스트 뷰 생성
        ListView listView_comments = (ListView) rootView.findViewById(R.id.listView_comments);
        //코멘트 어뎁터 객체 선언
        commentAdapter = new CommentAdapter(true);
        //예시 댓글 생성
        addItem();
        //리스트뷰에 어뎁터 적용
        listView_comments.setAdapter(commentAdapter);
        //각 버튼을 눌렀을 때 동작하는 메소드
        buttonClicked();

        return rootView;
    }
    //==========================onCreate 종료==========================


    public void setMovieDetail(){
        movie = new Bundle();
        movie = callback.getMovieDetail();
        Log.d("movie",movie.toString());

        String mvTitle = movie.getString("title");
        String resId = movie.getString("resId");
        String synopsis = movie.getString("synopsis");
        int audience = movie.getInt("audience");
        String date = movie.getString("date");
        int like = movie.getInt("like");
        int dislike = movie.getInt("dislike");
        String director = movie.getString("director");
        String actor = movie.getString("actor");
        //Log.d("movie",synopsis);
        Log.d("movie",like+" "+ dislike+"");


        sendImageRequest(resId);
        tvMovieTitle.setText(mvTitle);
        tvSynopsis.setText(synopsis);
        tvActor.setText(actor);
        tvDirector.setText(director);
        tvAudience.setText(audience+"");
        tvDate.setText(date);
        tvShowGood.setText(like+"");
        tvShowBad.setText(dislike+"");



    }

    public void sendImageRequest(String url1){
        String url = url1;
        ImageLoadTask task = new ImageLoadTask(url,imgMovie);
        task.execute();
    }



    //================버튼이 눌렸을 때 동작 함수=======================
    public void buttonClicked() {
        //좋아요 버튼을 눌렀을때
        btnGood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //아무것도 눌러져있지 않을때 상태 0
                if (goodBadState == 0) {
                    goodBadState = 1;
                    incLikeCount(goodBadState);

                }
                //좋아요 버튼이 눌러져있을때 상태  1
                else if (goodBadState == 1) {
                    decLikeCount(goodBadState);
                    goodBadState = 0;
                }
                //싫어요 버튼이 이미 눌러져 있을때 상태 2
                else {
                    decLikeCount(goodBadState);
                    goodBadState = 1;
                    incLikeCount(goodBadState);
                }
            }
        });

        //싫어요 버튼을 눌렀을때
        btnBad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //아무것도 눌러져있지 않을때 상태 0
                if(goodBadState==0){
                    goodBadState = 2;
                    incLikeCount(goodBadState);
                }
                //싫어요 버튼이 이미 눌러져 있을때 상태 2
                else if(goodBadState==2){
                    decLikeCount(goodBadState);
                    goodBadState = 0;
                }
                //좋아요 버튼이 눌러져있을때 상태 1
                else{
                    decLikeCount(goodBadState);
                    goodBadState = 2;
                    incLikeCount(goodBadState);
                }

            }
        });

        //작성하기 버튼을 눌렀을때
        btnWriteComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "작성하기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
                if(callback!=null){
                    callback.showCommentWriteActivity();
                }

            }
        });


        //모두보기 버튼 눌렀을때
        btnCommentShowAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "모두보기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
                if(callback!=null){
                    callback.showAllCommentActivity();
                }
            }
        });

        //카카오톡 버튼 눌렀을때
        btnKakao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "카카오톡 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        //페이스북 버튼 눌렀을때
        btnFaceBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "페이스북 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        //예매하기 버튼 눌렀을때
        btnReserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "예매하기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    //==========================예시 댓글 생성 함수=======================
    public void addItem(){
        Log.d("addItem ","디테일 프래그먼트에서 호출");
        //댓글 추가1
        commentAdapter.addItem(
                new CommentItem
                        ("ltwljh","적당히 재밌다. 오랜만에 잠안오는 영화를 봤네요",3.1f,R.drawable.user1,0));

        //댓글 추가2
        commentAdapter.addItem(
                new CommentItem
                        ("kartmon","영화가 너무 재미있었어요",4.2f,R.drawable.user1,2));

        //댓글 추가3
        commentAdapter.addItem(
                new CommentItem
                        ("kartmon2","영화가 너무 재미있었어요",4.2f,R.drawable.user1,1));

    }

    //==========================버튼을 눌렀을때 숫자 증가 메소드==========================
    public void incLikeCount(int good_bad_state) {
        //각각 좋아요갯수와 싫어요 갯수 가져오기
        likeGoodCount = Integer.parseInt(tvShowGood.getText().toString());
        likeBadCount = Integer.parseInt(tvShowBad.getText().toString());
        //좋아요 버튼을 눌렀을때
        if (good_bad_state == 1) {
            likeGoodCount++;
            tvShowGood.setText(String.valueOf(likeGoodCount));
            btnGood.setBackgroundResource(R.drawable.ic_thumb_up_selected);
        }
        //싫어요 버튼을 눌렀을때
        else {
            likeBadCount++;
            tvShowBad.setText(String.valueOf(likeBadCount));
            btnBad.setBackgroundResource(R.drawable.ic_thumb_down_selected);
        }
    }

    //==========================버튼을 눌렀을때 숫자 감소 메소드==========================
    public void decLikeCount(int goodBadState) {
        //각각 좋아요갯수와 싫어요 갯수 가져오기
        likeGoodCount = Integer.parseInt(tvShowGood.getText().toString());
        likeBadCount = Integer.parseInt(tvShowBad.getText().toString());

        //좋아요 버튼을 눌렀을때
        if (goodBadState == 1) {
            likeGoodCount--;
            tvShowGood.setText(String.valueOf(likeGoodCount));
            btnGood.setBackgroundResource(R.drawable.button_good_change);
        }

        //싫어요 버튼을 눌렀을때
        else {
            likeBadCount--;
            tvShowBad.setText(String.valueOf(likeBadCount));
            btnBad.setBackgroundResource(R.drawable.button_bad_change);
        }
    }
}

