package org.techtown.cinema;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.ArrayList;

public class MoviePagerAdapter extends FragmentStatePagerAdapter {

    ArrayList<Fragment> items = new ArrayList<Fragment>();

    //생성자
    public MoviePagerAdapter(FragmentManager fm) {
        super(fm);
    }

    //프래그먼트 추가하는 메소드
    public void addItem(Fragment item){
        items.add(item);
    }

    //프래그먼트 가져오는 메소드
    @Override
    public Fragment getItem(int position) {
        return items.get(position);
    }

    //프래그먼트의 개수를 가져오는 메소드
    @Override
    public int getCount() {
        return items.size();
    }
}
