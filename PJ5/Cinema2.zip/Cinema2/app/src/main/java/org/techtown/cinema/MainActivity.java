package org.techtown.cinema;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.util.Log;
import android.view.MenuItem;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.widget.Toast;

import org.techtown.cinema.data.MovieInfo;
import org.techtown.cinema.data.MovieList;
import org.techtown.cinema.data.ResponseInfo;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener ,FragmentCallback{

    FragmentMoviePager fragmentMoviePager;
    FragmentMovieList fragmentMovieList;
    FragmentMovieDetail fragmentMovieDetail;
    MoviePagerAdapter pagerAdapter;
    Intent intent;
    Bundle movieDetail;


    //==========================on Create==========================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_short_cut);

        fragmentMovieDetail = new FragmentMovieDetail();
        movieDetail = new Bundle();

        //프래그먼트에 영화 리스트 추가
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        if(AppHelper.requestQueue == null){
            AppHelper.requestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        requestMovieList();
        //requestCommentList();
    }

    //==========================on Create 종료==========================



    //==============영화 목록 가져오는 메소드==============
    public void requestMovieList(){
        String url = "http://" + AppHelper.host + ":" + AppHelper.port + "/movie/readMovieList";
        url += "?" + "type=1";

        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        println("응답 받음 => " + response);
                        requestCommentList();
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 발생 => " + error.getMessage());
                    }
                }
        );
        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
        println("영화목록 요청 보냄");
    }

    public void requestCommentList(){
        String url = "http://" + AppHelper.host + ":" + AppHelper.port + "/movie/readCommentList";
        url += "?" + "type=1";

        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 발생");
                    }
                }
        );
        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
        println("영화 댓글 요청 보냄");
    }


    //==============응답 데이터 처리 메소드==============
    public void processResponse(String response){
        Gson gson = new Gson();

        ResponseInfo info = gson.fromJson(response,ResponseInfo.class);
        if(info.code == 200){
            fragmentMoviePager = new FragmentMoviePager();
            pagerAdapter = new MoviePagerAdapter(getSupportFragmentManager());
            MovieList movieList = gson.fromJson(response,MovieList.class);
            println("영화 갯수 : " + movieList.result.size());

            for(int i=0;i<movieList.result.size();i++){
                MovieInfo movieInfo = movieList.result.get(i);

                Bundle movieDetail = new Bundle();
                movieDetail.putInt("num",movieInfo.id);
                movieDetail.putString("title",movieInfo.title);
                movieDetail.putFloat("rate",movieInfo.reservation_rate);
                movieDetail.putInt("age",movieInfo.grade);
                movieDetail.putString("resId",movieInfo.image);
                movieDetail.putString("resId2",movieInfo.thumb);


                Bundle movie = new Bundle();
                movie.putBundle("movie",movieDetail);


                fragmentMovieList = new FragmentMovieList();
                fragmentMovieList.setArguments(movie);
                println("영화 #" + i + " -> "+ movieInfo.id + ", " + movieInfo.title + ", " + movieInfo.grade);
                pagerAdapter.addItem(fragmentMovieList);
            }

            //프래그먼트 페이저에 어뎁터 전달
            fragmentMoviePager.setPager(pagerAdapter);
            //페이저 프래그먼트 호출
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container,fragmentMoviePager).commit();
        }
    }


    //==============로그 처리 메소드==============
    public void println(String data){
        Log.d("data : ", data+"\n");
    }

    //==============네비게이션 뒤로가기 처리 메소드==============
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }else if(fragmentMovieDetail != null){
            getSupportFragmentManager().beginTransaction().remove(fragmentMovieDetail).commit();
            Log.d("detail","실행");
            fragmentMovieDetail = null;
            requestMovieList();
        }else {
            super.onBackPressed();
        }
    }

    //==============네비게이션 버튼 선택 이동 메소드==============
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_list) {
            Toast.makeText(this,"영화 리스트 메뉴 선택됨.",Toast.LENGTH_LONG).show();
            requestMovieList();

        } else if (id == R.id.nav_api) {
            Toast.makeText(this,"영화 api 메뉴 선택됨.",Toast.LENGTH_LONG).show();
        } else if (id == R.id.nav_book) {
            Toast.makeText(this,"영화 예약 메뉴 선택됨.",Toast.LENGTH_LONG).show();
        } else if (id == R.id.nav_option) {
            Toast.makeText(this,"영화 옵션 메뉴 선택됨.",Toast.LENGTH_LONG).show();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //==============영화 목록 추가 메소드==============
//    public void setMovieList(int num,FragmentMovieList fragmentMovieList){
//        fragmentMovieList = new FragmentMovieList();
//
//        if(num == 1){
//            Bundle movie1 = newMovieList(1,"군 도",61.6,15,R.drawable.image1,
//                    R.drawable.image11);
//            fragmentMovieList.setArguments(movie1);
//
//        }
//        else if(num == 2){
//            Bundle movie2 = newMovieList(2,"공 조",61.6,15,R.drawable.image2,
//                    R.drawable.image22);
//            fragmentMovieList.setArguments(movie2);
//
//        }
//        else if(num == 3){
//            Bundle movie3 = newMovieList(3,"더 킹",61.6,15,R.drawable.image3,
//                    R.drawable.image33);
//            fragmentMovieList.setArguments(movie3);
//
//        }
//        else if(num ==4){
//            Bundle movie4 = newMovieList(4,"레지던트이블",61.6,15,R.drawable.image4,
//                    R.drawable.image44);
//            fragmentMovieList.setArguments(movie4);
//
//        }
//        else if(num ==5){
//            Bundle movie5 = newMovieList(5,"럭 키",61.6,15,R.drawable.image5,
//                    R.drawable.image55);
//            fragmentMovieList.setArguments(movie5);
//
//        }
//        else if(num == 6){
//            Bundle movie6 = newMovieList(6,"아수라",61.6,15,R.drawable.image6,
//                    R.drawable.image66);
//            fragmentMovieList.setArguments(movie6);
//
//        }
//
//        pagerAdapter.addItem(fragmentMovieList);
//    }

    //영화 정보를 번들로 저장하는 메소드
//    public Bundle newMovieList(int movieNum ,String movieTitle,float movieRate,int movieAge,String resId,
//                               String date, String
//                               String resId2
//    ){
//        Bundle movie = new Bundle();
//        movie.putInt("num",movieNum);
//        movie.putString("title",movieTitle);
//        movie.putFloat("rate",movieRate);
//        movie.putInt("age",movieAge);
//        movie.putString("resId",resId);
//        movie.putString("resId2",resId2);
//        return movie;
//    }

    public void setMovieDetail(Bundle bundle){
        movieDetail = new Bundle();
        movieDetail = bundle;
    }

    public Bundle getMovieDetail(){
        return movieDetail;
    }

    //==============상세화면 페이지로 전환하는 메소드==============
    public void onFragmentChange(){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container,fragmentMovieDetail).commit();
    }

    //==============모두 보기 버튼을 눌렀을 때 동작하는 메소드=============
    public void showAllCommentActivity(){
        intent = new Intent(getApplicationContext(),ShowAllCommentActivity.class);
        intent.putParcelableArrayListExtra("listData", fragmentMovieDetail.commentAdapter.getCommentItems());
        //intent.putParcelableArrayListExtra("listData",fragmentMovieDetail.commentItems);
        startActivityForResult(intent,101);
    }

    //================작성하기 버튼을 눌렀을 때 동작하는 메소드==========
    public void showCommentWriteActivity(){
        CommentItem commentItem = new CommentItem("kartmon","",0f,R.drawable.user1,0);
        intent = new Intent(getApplicationContext(),CommentWriteActivity.class);
        intent.putExtra("itemData",commentItem);
        startActivityForResult(intent,102);
    }

    //==========================onActivityResult==========================
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        //모두보기에서 돌아왔을 때 동작
        if(requestCode == 101 && intent!=null){
            ArrayList<CommentItem> commentItems;
            commentItems = intent.getParcelableArrayListExtra("returnList");
            fragmentMovieDetail.commentAdapter = new CommentAdapter(true);
            for(int i=0;i<commentItems.size();i++){
                fragmentMovieDetail.commentAdapter.addItem(commentItems.get(i));
            }
            fragmentMovieDetail.commentAdapter.notifyDataSetChanged();
        }

        //작성하기에서 돌아왔을 때 동작
        if(requestCode == 102 && intent !=null){
                CommentItem commentItem = intent.getParcelableExtra("returnData");
                //fragmentMovieDetail.commentItems.add(commentItem);
                fragmentMovieDetail.commentAdapter.addItem(commentItem);
                fragmentMovieDetail.commentAdapter.notifyDataSetChanged();
        }
    }
}
