package org.techtown.cinema.data;

//        id: 5606,
//        writer: "leap555",
//        movieId: 1,
//        writer_image: null,
//        time: "2019-09-09 10:31:03",
//        timestamp: 1567992663,
//        rating: 5,
//        contents: "드디어 등록 성공이군요.",
//        recommend: 0


public class MovieCommentList {
    int id;
    String writer;
    int movieId;
    String writer_image;
    String time;
    int timestamp;
    float rating;
    String contents;
    int recommend;


}
