package org.techtown.cinema.data;

import java.util.ArrayList;

public class MovieDetailList {
    public ArrayList<MovieDetail> result = new ArrayList<MovieDetail>();
}
