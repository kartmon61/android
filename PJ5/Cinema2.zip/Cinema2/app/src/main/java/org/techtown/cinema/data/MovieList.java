package org.techtown.cinema.data;

import java.util.ArrayList;

public class MovieList {

    public ArrayList<MovieInfo> result = new ArrayList<MovieInfo>();

}
